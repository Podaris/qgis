# -*- coding: utf-8 -*-
"""
/***************************************************************************
 PodarisDialog
                                 A QGIS plugin
 QGIS plugin for interacting with the Podaris platform
                             -------------------
        begin                : 2017-10-17
        git sha              : $Format:%H$
        copyright            : (C) 2017 by Podaris Ltd
        email                : support@podaris.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import os

from qgis.gui import QgsMessageBar
from PyQt4 import QtGui, uic, QtCore
import urllib.request, json 
from operator import itemgetter

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'import_view.ui'))


class ImportView(QtGui.QDialog, FORM_CLASS):
    def __init__(self, api, iface):
        """Constructor."""
        super(ImportView, self).__init__(None)
        self.api=api
        self.iface=iface
        # Set up the user interface from Designer.
        # After setupUI you can access any designer object by doing
        # self.<objectname>, and you can use autoconnect slots - see
        # http://qt-project.org/doc/qt-4.8/designer-using-a-ui-file.html
        # #widgets-and-dialogs-with-auto-connect
        self.setupUi(self)
        self.connect(self.projectSelect, QtCore.SIGNAL('activated(int)'), self.project_changed)
        self.connect(self.directorySelectBtn, QtCore.SIGNAL("clicked()"), self.choose_dir)

    def project_changed(self,i):
        selectedProject = self.projectSelect.itemData(i)
        self.load_views(selectedProject)
        
    def load_views(self, projectId):
        self.viewSelect.clear()
        error, views=self.api.Projects.views(projectId)
        if error != None:
            self.iface.messageBar().pushMessage("Unable to Load Views", error['reason'], level=QgsMessageBar.CRITICAL)
        else:
            for view in views:
                self.viewSelect.addItem(view["title"], view["id"])

    def load_projects(self):
        self.projectSelect.clear()
        error, projects = self.api.Projects().find()
        if error != None:
            self.iface.messageBar().pushMessage("Unable to Load Projects", error['reason'], level=QgsMessageBar.CRITICAL)
        else:
            sortedProjects = sorted(projects, key=itemgetter("title"))
            for project in sortedProjects:
                self.projectSelect.addItem(project["title"], project["id"])
            self.projectSelect.setCurrentIndex(-1)

    def clear_selected(self):
        self.projectSelect.setCurrentIndex(-1)
        self.viewSelect.setCurrentIndex(-1)

    def choose_dir(self):
        browser = QtGui.QFileDialog()
        browser.setFileMode(QtGui.QFileDialog.Directory)
        browser.setOption(QtGui.QFileDialog.ShowDirsOnly)
        directory = browser.getExistingDirectory(self, 'Choose Directory', os.path.curdir)
        self.saveDestination.setText(directory)
