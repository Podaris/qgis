import requests

HOST = "https://api-beta.podaris.com" 
TOKEN = ""
USER = False

def authenticate(token):
    global TOKEN, USER
    TOKEN=token
    if token != "":
        error, USER=httpGet('/userinfo')
    else:
        error={'code': 401, 'reason': 'Invalid access token'}
    return error

class Projects():
    ENDPOINT = "/projects"

    @classmethod
    def find(cls):
        return httpGet(cls.ENDPOINT)

    @classmethod
    def findOne(cls, id):
        path='%s/%s' % (cls.ENDPOINT, id)
        return httpGet(path)

    @classmethod
    def views(cls, id):
        path='%s/%s/views' % (cls.ENDPOINT, id)
        return httpGet(path)

class Views():
    ENDPOINT = "/views"

    @classmethod
    def findOne(cls, id):
        path='%s/%s' % (cls.ENDPOINT, id)
        return httpGet(path)

    @classmethod
    def network(cls, id):
        path='%s/%s/network' % (cls.ENDPOINT, id)
        return httpGet(path)

def httpGet(path):
    url = HOST + path
    headers = {"Authorization":"Bearer %s" % TOKEN}
    error=None
    response=None
    r = requests.get(url, headers=headers)
    if r.status_code > 299:
        if r.status_code == 401:
            error = {'code': 401, 'reason': 'Invalid access token'}
        else:
            reason=r.json()
            error={
                'code': err.status_code,
                'reason': reason['message'] 
            }
    else:
        response=r.json()
    return error, response 
