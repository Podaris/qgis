# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Podaris
                                 A QGIS plugin
 QGIS plugin for interacting with the Podaris platform
                              -------------------
        begin                : 2017-10-17
        git sha              : $Format:%H$
        copyright            : (C) 2017 by Podaris Ltd
        email                : support@podaris.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from PyQt4.QtGui import QAction, QIcon, QColor
from qgis.gui import QgsMessageBar
from qgis.core import *
# Initialize Qt resources from file resources.py
import resources
# Import the code for the dialog
from ui.import_view import ImportView
from ui.authenticate import Authenticate
import os.path
import json
from Podaris import api

class Podaris:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor.
        """
        # Save reference to the QGIS interface
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)

        # Declare instance attributes
        self.actions = []
        self.menu = u'&Podaris'
  
    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        status_tip=None,
        whats_this=None,
        parent=None):

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_menu:
            self.iface.addPluginToWebMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""

        icon_path = ':/plugins/Podaris/icon.png'
        self.add_action(
            icon_path,
            text=u'Import project view',
            callback=self.import_view,
            parent=self.iface.mainWindow())


    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginWebMenu(
                u'&Podaris',
                action)

    def unauthenticate(self):
        if hasattr(self, "logoutAction"):
            self.iface.removePluginWebMenu(
                u'&Podaris',
                self.logoutAction)
            del self.logoutAction
        api.Token=""
        api.USER=False

    def authenticate(self):
        self.unauthenticate()
        dlg=Authenticate(api)
        dlg.show()
        result = dlg.exec_()
        if result:
            token = dlg.accessToken.text()
            error=api.authenticate(token)
            if error:
                self.unauthenticate()
                self.iface.messageBar().pushMessage("Unable to Login", error['reason'], level=QgsMessageBar.CRITICAL)
            else:
                icon_path = ':/plugins/Podaris/icon.png'
                self.logoutAction = self.add_action(
                    icon_path,
                    text=u'Logout',
                    callback=self.unauthenticate,
                    parent=self.iface.mainWindow()
                )

    def import_view(self):
        if api.USER == False:
            self.authenticate()
        if api.USER != False:
            dlg = ImportView(api, self.iface)
            # show the dialog
            dlg.show()
            # Run the dialog event loop
            dlg.load_projects()
            result = dlg.exec_()
            # See if OK was pressed
            if result:
                projectId = dlg.projectSelect.itemData(dlg.projectSelect.currentIndex())
                viewId = dlg.viewSelect.itemData(dlg.viewSelect.currentIndex())
                directory = dlg.saveDestination.text()
                if projectId == None or viewId == None or directory == "":
                    pass
                else:
                    error, data = api.Views.network(viewId)
                    if error != None:
                        self.iface.messageBar().pushMessage("Unable to Import Network", error['reason'], level=QgsMessageBar.CRITICAL)
                    else:
                        root = QgsProject.instance().layerTreeRoot()
                        if root.findGroup(data["projectName"]) == None:
                            root.addGroup(data["projectName"])

                        projectGroup = root.findGroup(data["projectName"])
                        if projectGroup.findGroup(data["viewName"]) == None:
                            projectGroup.addGroup(data["viewName"])
                        viewGroup = projectGroup.findGroup(data["viewName"])

                        baseFileName = "{}-{}-{}.geojson".format(data["projectName"], data["viewName"], data["projectVersion"])
                        pathToStations = os.path.join(directory,"stations-{}".format(baseFileName))
                        pathToLines = os.path.join(directory,"network-{}".format(baseFileName))

                        with open(pathToStations, 'w') as outfile:
                            json.dump(data["network"]["ControlPoints"], outfile)
                        with open(pathToLines, 'w') as outfile:
                            json.dump(data["network"]["ControlLines"], outfile)

                        lines = QgsVectorLayer(pathToLines,"Network","ogr")
                        stations = QgsVectorLayer(pathToStations,"Stations","ogr")

                        stations.setCustomProperty("labeling", "pal")
                        stations.setCustomProperty("labeling/enabled", "true")
                        stations.setCustomProperty("labeling/fontSize", "9")
                        stations.setCustomProperty("labeling/fieldName", "name")
                        stations.setCustomProperty("labeling/placement", "1")
                        stations.setCustomProperty("labeling/placementFlags", "10")
                        stations.setCustomProperty("labeling/yOffset", "-2")
                        stations.setCustomProperty("labeling/offsetType", "0")
                        stations.setCustomProperty("labeling/quadOffset", "1")
                        stations.setCustomProperty("labeling/labelOffsetInMapUnits","false")

                        QgsMapLayerRegistry.instance().addMapLayer(lines, False) 
                        QgsMapLayerRegistry.instance().addMapLayer(stations, False) 

                        viewGroup.addLayer(stations)
                        viewGroup.addLayer(lines)

                        for isochron in data["isochrones"]:
                            pathToLayer = os.path.join(directory,"isochron-{}-{}".format(isochron["properties"]["_id"],
                                baseFileName))
                            with open(pathToLayer, 'w') as outfile:
                                json.dump(isochron, outfile)
                            layer = QgsVectorLayer(pathToLayer,"Isochron","ogr")
                            QgsMapLayerRegistry.instance().addMapLayer(layer, False) 
                            viewGroup.addLayer(layer)
                            fill = QgsFillSymbolV2.createSimple({
                                'border_width_map_unit_scale': '0,0,0,0,0,0',
                                'color':'143,72,64,255',
                                'color_dd_active':'1',
                                'color_dd_expression': '',
                                'color_dd_field': 'fill',
                                'color_dd_useexpr': '0',
                                'outline_color':'0,0,0,'
                                })
                            layer.setRendererV2(QgsSingleSymbolRendererV2(fill)) 
                            layer.setLayerTransparency(isochron["properties"]["transparency"])
                            self.dlg.clear_selected()

                        self.add_color_by_layer_styles(data["layers"], lines)
                        self.add_color_by_layer_styles(data["layers"], stations)

    def add_color_by_layer_styles(self, layers, mapLayer): 
        symbol = QgsSymbolV2.defaultSymbol(mapLayer.geometryType())
        renderer = QgsRuleBasedRendererV2(symbol)
        root_rule = renderer.rootRule()
        for layer in layers:
            if layer["type"] != "overlay" and layer["isVisible"] == True:
                rule = root_rule.children()[0].clone()
                rule.setLabel(layer["title"])
                rule.setFilterExpression("layerId ='{}'".format(layer["_id"]))
                rule.symbol().setColor(QColor(layer["color"]))
                root_rule.appendChild(rule)
        root_rule.removeChildAt(0)
        mapLayer.setRendererV2(renderer)
